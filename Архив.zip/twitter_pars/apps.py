from django.apps import AppConfig


class TwitterParsConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'twitter_pars'
